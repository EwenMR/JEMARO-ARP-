function R = ComputeAngleAxis(theta,v)
%Implement here the Rodrigues formula

end
