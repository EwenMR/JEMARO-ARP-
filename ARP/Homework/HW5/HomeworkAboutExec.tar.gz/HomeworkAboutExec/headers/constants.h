#ifndef CONSTANTS
#define CONSTANTS

#define CHILDS_NUM 2
#define MAX_MESSAGE_LEN 100

#endif // !CONSTANTS


