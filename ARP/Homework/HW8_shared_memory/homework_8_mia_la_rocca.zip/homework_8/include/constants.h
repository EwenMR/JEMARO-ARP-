#ifndef CONSTANTS_H
#define CONSTANTS_H

#define SHMOBJ_PATH "/shm_server"
#define SEM_PATH "/sem_server"

#define SEED_MULTIPLIER 120
#define MAX_NUMBER 50


#endif // !CONSTANTS_H