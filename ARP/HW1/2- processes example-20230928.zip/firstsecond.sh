konsole  -e ./second &
konsole  -e ./first &
