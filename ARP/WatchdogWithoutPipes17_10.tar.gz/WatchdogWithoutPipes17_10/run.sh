cd build
make clean
cmake ..
cd ..
cmake --build build
./watchdog
