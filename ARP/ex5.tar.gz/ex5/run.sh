make clean
make
./master
