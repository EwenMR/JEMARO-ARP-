#ifndef CONSTANTS_H
#define CONSTANTS_H

#define MAX_MSG_LEN 300
#define MAX_LOGGER_LEN 100

#endif // !CONSTANTS_H
